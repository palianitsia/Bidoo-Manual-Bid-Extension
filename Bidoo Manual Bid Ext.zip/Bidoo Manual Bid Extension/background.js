// Questa funzione verifica se l'URL della scheda corrente corrisponde a una pagina d'asta
function isAuctionPage(url) {
  // Verifica se l'URL contiene il percorso delle aste
  return url.includes("/auction.php?a=");
}

chrome.tabs.onUpdated.addEventListener('updated', function(tabId, changeInfo, tab) {
  // Controlla se l'URL della scheda è cambiato e se è una pagina d'asta
  if (changeInfo.status === 'complete' && isAuctionPage(tab.url)) {
    // Invia un messaggio per attivare il codice dell'asta
    chrome.tabs.sendMessage(tabId, {
      action: 'start' // Invia un messaggio per avviare l'interazione con la pagina d'asta
    });
  }
});

chrome.runtime.onMessage.addEventListener('message', function(request, sender, sendResponse) {
  if (request.action === 'stop') {
    // Interrompi qualsiasi azione quando ricevi il messaggio di stop
    // (Se c'è una funzione specifica da fermare, inserirla qui)
  }
});
