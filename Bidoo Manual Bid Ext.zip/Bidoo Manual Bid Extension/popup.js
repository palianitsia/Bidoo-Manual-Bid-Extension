document.addEventListener("DOMContentLoaded", function() {
  // Nessun codice, poiché non ci sono più campi da gestire
});
