// Funzione per simulare il movimento del mouse verso il pulsante e fare clic su di esso
function simulateMouseMovementToButton() {
    const buttonSelector = 'a.bid-button.button-default.button-rounded.button-full.ripple-button.button-big-text.auction-btn-bid.button-mint-flat.bid-button-active.hidden-xs';
    const button = document.querySelector(buttonSelector);
    if (button) {
        const buttonRect = button.getBoundingClientRect();
        const eventOptions = {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: buttonRect.left + buttonRect.width / 2,
            clientY: buttonRect.top + buttonRect.height / 2
        };
        const mousemoveEvent = new MouseEvent('mousemove', eventOptions);
        window.dispatchEvent(mousemoveEvent);
    }
}

// Funzione per controllare il timer e fare clic sul pulsante in modalità manuale
function checkTimerAndClickButton() {
    const timerSelector = 'div.text-countdown-progressbar';
    const timer = document.querySelector(timerSelector);
    if (timer && timer.innerText.trim() === '0') {
        const buttonSelector = 'a.bid-button.button-default.button-rounded.button-full.ripple-button.button-big-text.auction-btn-bid.button-mint-flat.bid-button-active.hidden-xs';
        const button = document.querySelector(buttonSelector);
        if (button) {
            button.click();
        }
    }
}

// Eseguire le funzioni ad intervalli regolari
setInterval(simulateMouseMovementToButton, 250);
setInterval(checkTimerAndClickButton, 1000);

// Funzione per verificare se l'utente ha finito i crediti o se l'asta è terminata
function checkCreditsAndAuctionStatus() {
    const creditsElement = document.getElementById("divSaldoBidBottom");
    const auctionStatusElement = document.querySelector('a.bid-button.button-default.button-rounded.button-full.ripple-button.button-big-text.auction-btn-bid.button-gray-flat.bid-button-disabled.hidden-xs');

    if (creditsElement && parseInt(creditsElement.innerText) <= 0) {
        clearInterval(creditsAndAuctionInterval);
    }

    if (auctionStatusElement && auctionStatusElement.style.display !== "none") {
        clearInterval(creditsAndAuctionInterval);
    }
}

// Eseguire la funzione di controllo dei crediti e dello stato dell'asta ad intervalli regolari
const creditsAndAuctionInterval = setInterval(checkCreditsAndAuctionStatus, 500);
